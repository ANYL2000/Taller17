$(document).on('click','#enviar_individual',function(){

    let obtenerFila = document.getElementsByClassName("filas_secundarias");
    let elementosFila = obtenerFila[1].getElementsByTagName("td");

    
        

        let valor_folio = elementosFila[0];
        let valor_codigo = elementosFila[1];

        console.log(valor_folio);
        console.log(valor_codigo);
        
        let valor_texto_folio = valor_folio.childNodes[0].textContent;
        let valor_texto_codigo = valor_codigo.childNodes[0].textContent;
        
        console.log(valor_texto_folio);
        console.log(valor_texto_codigo);
         

  
  
   /* let codigo = elementosFila[1];

   $.ajax({
        type: "POST",
        url: 'enviar_constancias_pdf.php',
        data: {'folio': folio },//capturo array   JSON.stringify(  
        success: function(data){
        alert(data);
      }
    });*/

});